﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Das4
{
    public partial class Form1 : Form
    {
        class Flat
        {
            private int number;
            private int area;
            private string adress;

            public int Number
            {
                get { return number; }
                set { number = value; }
            }

            public int Area
            {
                get { return area; }
                set { area = value; }
            }

            public int Floor { get; set; }
            public bool HasBalcony { get; set; }

            public double EstimatedPrice
            {
                get { return area * 1000; }
            }

            public Flat()
            {
                Number = 0;
                Area = 50;
                adress = "Невідомо";
                Floor = 1;
                HasBalcony = false;
            }

            public Flat(int number, int area, string adress, int floor, bool hasBalcony)
            {
                Number = number;
                Area = area;
                this.adress = adress;
                Floor = floor;
                HasBalcony = hasBalcony;
            }

            public string GetAdress() { return adress; }

            public void SetAdress(string adress) { this.adress = adress; }

            public void UpdateFloor(int newFloor)
            {
                Floor = newFloor;
            }

            public void UpdateArea(ref int newArea)
            {
                Area = newArea;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        Flat fFlat = null;

        private void btnSave_Click(object sender, EventArgs e)
        {
            fFlat = new Flat(
               Convert.ToInt32(tbNumber.Text),
               Convert.ToInt32(tbArea.Text),
               tbAdress.Text,
               Convert.ToInt32(tbFloor.Text),
               cbBalcony.Checked
           );
            MessageBox.Show("Save success");
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Номер квартири: " + fFlat.Number + "\n" +
                "Площа квартири: " + fFlat.Area + "\n" +
                "Поверх: " + fFlat.Floor + "\n" +
                "Балкон: " + (fFlat.HasBalcony ? "Так" : "Ні") + "\n" +
                "Адреса квартири: " + fFlat.GetAdress() + "\n" +
                "Вартість: " + fFlat.EstimatedPrice + "\n",
                "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    
}
